#include <iostream>
#include <vector>
#include <algorithm>
#include <time.h>

using namespace std;

int main()
{
    int a = clock();
    FILE *file = fopen("test3000.txt", "r");
    int N, V;
    fscanf(file, "%d%d", &N, &V);
    vector<int> v(N + 1), w(N + 1), f(V + 1);
    for(int i = 1; i <= N; ++i)
        fscanf(file, "%d%d", &v[i], &w[i]);
    fclose(file);
    for(int i = 1; i <= N; ++i)
        for(int j = V; j >= v[i]; --j)
            f[j] = max(f[j], f[j - v[i]] + w[i]);
    cout << *max_element(f.begin(), f.end()) << endl;
    printf("cost: %dms", clock() - a);
    system("pause");
    return 0;
}