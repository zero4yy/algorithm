#include <iostream>
#include <vector>
#include <algorithm>
#include <time.h>

using namespace std;

struct item
{
    double v, w;
};

int bestw = 0, N, V;
vector<item> items;

bool cmp(const item &a, const item &b)
{
    return a.w / a.v > b.w / b.v;
}

double evalue(int i, double cv)
{
    double upperbound = 0, vleft = V - cv;
    for(int k = i; k <= N; ++k)
    {
        if(vleft >= items[k].v)
        {
            upperbound += items[k].w;
            vleft -= items[k].v;
        }
        else
        {
            upperbound += items[k].w / items[k].v * vleft;
            return upperbound;
        }
    }
    return upperbound;
}

void backtrack(int i, double cv, double cw)
{
    if(i > N)
    {
        bestw = bestw > cw ? bestw : cw;
        return;
    }
    if(cv + items[i].v <= V)
        backtrack(i + 1, cv + items[i].v, cw + items[i].w);
    if(cw + evalue(i + 1, cv) > bestw)
        backtrack(i + 1, cv, cw);
}

int main()
{
    int a = clock();
    FILE *file = fopen("test3000.txt", "r");
    fscanf(file, "%d%d", &N, &V);
    items.resize(N + 1);
    for(int i = 1; i <= N; ++i)
        fscanf(file, "%lf%lf", &items[i].v, &items[i].w);
    fclose(file);
    sort(items.begin() + 1, items.end(), cmp);
    backtrack(1, 0, 0);
    cout << bestw << endl;
    printf("cost: %dms", clock() - a);
    system("pause");
    return 0;
}