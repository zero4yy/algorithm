#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <time.h>

using namespace std;

struct item
{
    double v, w;
};

struct node
{
    int cw, cv, i;
    double B;
    node(int cv, int cw, int i, double B) : cv(cv), cw(cw), i(i), B(B) {}
    bool operator<(const node &b) const
    {
        return this -> B < b.B;
    }
};

int bestw = 0, N, V;
vector<item> items;

bool cmp(const item &a, const item &b)
{
    return a.w / a.v > b.w / b.v;
}

double evalue(int i, double cv)
{
    double upperbound = 0, vleft = V - cv;
    for(int k = i; k <= N; ++k)
    {
        if(vleft >= items[k].v)
        {
            upperbound += items[k].w;
            vleft -= items[k].v;
        }
        else
        {
            upperbound += items[k].w / items[k].v * vleft;
            return upperbound;
        }
    }
    return upperbound;
}

void Knapsacks()
{
    priority_queue<node> Q;
    Q.push(node(0, 0, 1, evalue(1, 0)));
    node temp(0, 0, 0, 0);
    while(!Q.empty())
    {
        temp =  Q.top();
        Q.pop();
        if(temp.i > N)
        {
            bestw = temp.cw;
            return;
        }
        double &vi = items[temp.i].v;
        double &wi = items[temp.i].w;
        double nextB = temp.cw + evalue(temp.i + 1, temp.cv);
        if(temp.cv + vi <= V)
        {
            Q.push(node(temp.cv + vi, temp.cw + wi, temp.i + 1, temp.B));
            bestw = bestw > temp.cw + wi ? bestw : temp.cw + wi;
        }
        if(nextB > bestw)
            Q.push(node(temp.cv, temp.cw, temp.i + 1, nextB));
    }
}

int main()
{
    int a = clock();
    FILE *file = fopen("test3000.txt", "r");
    fscanf(file, "%d%d", &N, &V);
    items.resize(N + 1);
    for(int i = 1; i <= N; ++i)
        fscanf(file, "%lf%lf", &items[i].v, &items[i].w);
    fclose(file);
    sort(items.begin() + 1, items.end(), cmp);
    Knapsacks();
    cout << bestw << endl;
    printf("cost: %dms", clock() - a);
    system("pause");
    return 0;
}